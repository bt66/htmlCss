const text = document.querySelector('.navbar .nav .nav-link .bar h1')
const bar = document.querySelector('.navbar .nav .nav-link .bar')
const tomobile = document.querySelector('.navbar .nav .nav-link ul')
const nav = document.querySelectorAll('.navbar .nav .nav-link ul li a')

const bgNavbar = document.querySelector('header .navbar')

bar.addEventListener('click',() => {
    if (text.innerHTML === 'X') {
        text.innerHTML = '='
    }else {
        text.innerHTML = 'X'
    }
    tomobile.classList.toggle('toggle-open')
})

nav.forEach((item) => {
    item.addEventListener('click',()=>{
        if (text.innerHTML === 'X') {
            text.innerHTML = '='
        }else {
            text.innerHTML = 'X'
        }
        tomobile.classList.toggle('toggle-open')
    })
});
document.addEventListener('scroll',() =>{
    let scroll = window.scrollY
    if (scroll >150) {
        bgNavbar.style.backgroundColor = 'rgb(45, 39, 51)'
    }else{
        bgNavbar.style.backgroundColor = 'rgba(0, 0, 0, 0.267)'
    }
})